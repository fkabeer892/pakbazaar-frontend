<template>
  <div>
    <a-layout-header class="bg-white" />
  </div>
</template>
