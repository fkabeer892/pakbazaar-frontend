<template>
  <div>
    <img src="/logo.png" />
  </div>
</template>

<style></style>
