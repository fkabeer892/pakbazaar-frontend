import { wrapFunctional } from './utils'

export { default as Logo } from '../..\\components\\Logo.vue'
export { default as LayoutFooter } from '../..\\components\\Layout\\Footer.vue'
export { default as LayoutHeader } from '../..\\components\\Layout\\Header.vue'
export { default as LayoutSidebar } from '../..\\components\\Layout\\Sidebar.vue'

export const LazyLogo = import('../..\\components\\Logo.vue' /* webpackChunkName: "components/logo" */).then(c => wrapFunctional(c.default || c))
export const LazyLayoutFooter = import('../..\\components\\Layout\\Footer.vue' /* webpackChunkName: "components/layout-footer" */).then(c => wrapFunctional(c.default || c))
export const LazyLayoutHeader = import('../..\\components\\Layout\\Header.vue' /* webpackChunkName: "components/layout-header" */).then(c => wrapFunctional(c.default || c))
export const LazyLayoutSidebar = import('../..\\components\\Layout\\Sidebar.vue' /* webpackChunkName: "components/layout-sidebar" */).then(c => wrapFunctional(c.default || c))
