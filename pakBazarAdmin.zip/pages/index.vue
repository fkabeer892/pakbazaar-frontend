<template>
  <div class="dashboard"><h1>Dashboard</h1></div>
</template>

<script>
export default {}
</script>

<style>
.dashboard {
  margin: 0 auto;
  min-height: 100vh;
}
</style>
