import Vue from 'vue'
import Antd from 'ant-design-vue'

Vue.use(Antd)
